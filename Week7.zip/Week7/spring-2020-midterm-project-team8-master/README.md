# Midterm Project
Group #   
Partner 1:   
Partner 2:   
   
The purpose of this project is to.... 
My website was working on windows 10   
which was disabled by using my laptop on campus
winona university  so I need help to start it back
We learned/got help from the following resources...   
